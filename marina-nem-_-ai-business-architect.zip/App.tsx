
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ChatAudit from './components/ChatAudit';
import VoiceStrategist from './components/VoiceStrategist';
import CreativeEngine from './components/CreativeEngine';
import { AppSection } from './types';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.Audit);

  const renderSection = () => {
    switch (activeSection) {
      case AppSection.Audit:
        return <ChatAudit />;
      case AppSection.Voice:
        return <VoiceStrategist />;
      case AppSection.Creative:
        return <CreativeEngine />;
      default:
        return <ChatAudit />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />
      
      <main className="flex-1 flex flex-col relative overflow-y-auto">
        <header className="p-6 glass border-b border-slate-800 flex justify-between items-center sticky top-0 z-10">
          <div>
            <h1 className="text-2xl font-luxury tracking-tight text-amber-500">
              MARINA NEM <span className="text-slate-500 font-sans text-sm ml-2">DIGITAL TWIN v2.5</span>
            </h1>
            <p className="text-xs text-slate-400 uppercase tracking-widest mt-1">Dark Tech Luxury Architecture</p>
          </div>
          <div className="flex items-center gap-4">
             <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded text-[10px] text-amber-500 font-bold uppercase">
               Premium Strategist Mode
             </div>
          </div>
        </header>

        <div className="flex-1 p-4 md:p-8">
          {renderSection()}
        </div>
      </main>
    </div>
  );
};

export default App;
