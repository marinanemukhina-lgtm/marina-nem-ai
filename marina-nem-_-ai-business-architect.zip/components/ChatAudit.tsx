
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { MARINA_SYSTEM_INSTRUCTION, MODELS } from '../constants';
import { Message } from '../types';

const ChatAudit: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Приветствую. Я готова приступить к анализу вашей бизнес-архитектуры. Для формирования предметных рекомендаций, пожалуйста, уточните вашу нишу, показатели текущего оборота и основные точки эрозии маржинальности.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const chat = ai.chats.create({
        model: MODELS.CHAT,
        config: {
          systemInstruction: MARINA_SYSTEM_INSTRUCTION,
        },
      });

      const response = await chat.sendMessage({ message: input });
      const modelText = response.text || "Произошла системная девиация при формировании ответа. Пожалуйста, повторите запрос.";
      
      setMessages(prev => [...prev, { role: 'model', text: modelText }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Ошибка сетевого протокола. Проверьте стабильность соединения с API." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-12rem)] flex flex-col glass rounded-2xl border border-slate-800 shadow-2xl overflow-hidden">
      <div className="p-4 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Сессия стратегического аудита</span>
        </div>
        <button 
          onClick={() => setMessages([{ role: 'model', text: 'Контекст обнулен. Я готова к новой архитектурной сессии. Какую нишу мы декомпозируем?' }])}
          className="text-[10px] text-slate-500 hover:text-slate-300 transition-colors font-bold uppercase"
        >
          Сбросить контекст
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl p-4 ${
              msg.role === 'user' 
                ? 'bg-amber-500 text-slate-950 rounded-tr-none' 
                : 'bg-slate-800/80 text-slate-200 border border-slate-700 rounded-tl-none shadow-xl'
            }`}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              {msg.role === 'model' && (
                <div className="mt-3 flex items-center gap-2 border-t border-slate-700/50 pt-2">
                   <span className="text-[10px] font-bold text-amber-500/60 uppercase tracking-tighter">Strategic Insight Architecture</span>
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700 rounded-tl-none flex gap-2">
              <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-slate-900/80 border-t border-slate-800">
        <div className="relative group">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Сформулируйте ваш запрос (например: оптимизация конверсии в люкс-сегменте)..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-6 py-4 pr-16 focus:outline-none focus:border-amber-500 transition-all text-sm placeholder:text-slate-600 group-hover:border-slate-500"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-amber-500 text-slate-950 rounded-lg disabled:opacity-50 hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/10"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatAudit;
