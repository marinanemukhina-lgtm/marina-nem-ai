
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { MODELS } from '../constants';

const CreativeEngine: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [resultVideo, setResultVideo] = useState<string | null>(null);
  const [mode, setMode] = useState<'edit' | 'animate'>('edit');
  const [statusMessage, setStatusMessage] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        resolve(base64);
      };
      reader.onerror = error => reject(error);
    });
  };

  const checkAndSelectKey = async () => {
    if (!(window as any).aistudio) return true;
    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await (window as any).aistudio.openSelectKey();
    }
    return true;
  };

  const handleProcess = async () => {
    if (!selectedFile || !prompt.trim() || isProcessing) return;
    
    setIsProcessing(true);
    setStatusMessage(mode === 'edit' ? 'Производится ревизия визуальной архитектуры...' : 'Генерация динамической проекции бренда...');
    setResultImage(null);
    setResultVideo(null);

    try {
      await checkAndSelectKey();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const base64 = await fileToBase64(selectedFile);

      if (mode === 'edit') {
        const response = await ai.models.generateContent({
          model: MODELS.IMAGE,
          contents: {
            parts: [
              { inlineData: { data: base64, mimeType: selectedFile.type } },
              { text: prompt }
            ]
          }
        });

        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setResultImage(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
          }
        }
      } else {
        let operation = await ai.models.generateVideos({
          model: MODELS.VIDEO,
          prompt: prompt,
          image: {
            imageBytes: base64,
            mimeType: selectedFile.type,
          },
          config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
          }
        });

        while (!operation.done) {
          setStatusMessage(`Рендеринг видеопотока (Veo Engine v3.1)...`);
          await new Promise(resolve => setTimeout(resolve, 10000));
          operation = await ai.operations.getVideosOperation({ operation: operation });
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (downloadLink) {
           const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
           const blob = await videoResponse.blob();
           setResultVideo(URL.createObjectURL(blob));
        }
      }
    } catch (err: any) {
      console.error(err);
      setStatusMessage(`Критическая ошибка: ${err.message || 'Системный сбой при обработке запроса'}`);
    } finally {
      setIsProcessing(false);
      setStatusMessage('');
    }
  };

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
      <div className="space-y-6">
        <div className="p-6 glass rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button 
              onClick={() => setMode('edit')}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'edit' ? 'bg-amber-500 text-slate-950' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Визуальный Редактор
            </button>
            <button 
              onClick={() => setMode('animate')}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'animate' ? 'bg-amber-500 text-slate-950' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Анимация Veo
            </button>
          </div>

          <div className="space-y-4">
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400">Исходный Актив Брендинга</label>
            <div 
              className={`relative h-64 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer overflow-hidden ${
                imagePreview ? 'border-amber-500/50' : 'border-slate-800 hover:border-slate-600'
              }`}
            >
              {imagePreview ? (
                <img src={imagePreview} className="w-full h-full object-contain" alt="Preview" />
              ) : (
                <div className="text-center p-6">
                  <svg className="w-12 h-12 text-slate-700 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <p className="text-xs text-slate-500">Загрузите имидж для трансформации</p>
                </div>
              )}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-xs font-bold uppercase tracking-widest text-slate-400">Креативная Директива</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={mode === 'edit' ? "Например: 'Интегрировать премиальное освещение и айдентику Max Mara'..." : "Например: 'Создать элегантную динамику движения шелка в кадре'..."}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-sm min-h-[100px] focus:outline-none focus:border-amber-500 transition-all placeholder:text-slate-700"
            />
          </div>

          <button
            onClick={handleProcess}
            disabled={isProcessing || !selectedFile || !prompt.trim()}
            className="w-full py-4 bg-amber-500 text-slate-950 rounded-xl font-bold uppercase tracking-widest text-sm hover:bg-amber-400 disabled:opacity-30 transition-all shadow-lg shadow-amber-950/20"
          >
            {isProcessing ? 'Трансформация...' : 'Реализовать Видение'}
          </button>
          
          {statusMessage && (
            <p className="text-[10px] text-center text-amber-500/80 font-bold uppercase animate-pulse">
              {statusMessage}
            </p>
          )}
        </div>
      </div>

      <div className="h-full flex flex-col">
        <div className="p-6 glass rounded-2xl border border-slate-800 shadow-xl h-full flex flex-col items-center justify-center relative min-h-[400px]">
          <div className="absolute top-4 left-4">
             <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 bg-slate-950/50 px-2 py-1 rounded">Финальный Рендер</span>
          </div>

          {!resultImage && !resultVideo && !isProcessing && (
            <div className="text-center opacity-20">
              <svg className="w-32 h-32 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
              <p className="text-sm">Ожидание генерации актива...</p>
            </div>
          )}

          {isProcessing && (
            <div className="flex flex-col items-center gap-6">
              <div className="w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Проектирование контента...</p>
            </div>
          )}

          {resultImage && (
            <div className="w-full h-full flex flex-col">
              <img src={resultImage} className="w-full h-full object-contain rounded-lg" alt="Result" />
              <a href={resultImage} download="marina-nem-asset.png" className="mt-4 text-center text-[10px] text-amber-500 uppercase font-bold hover:underline">Экспортировать High-Res Актив</a>
            </div>
          )}

          {resultVideo && (
            <div className="w-full h-full flex flex-col">
              <video src={resultVideo} controls autoPlay loop className="w-full h-full rounded-lg" />
              <a href={resultVideo} download="marina-nem-veo.mp4" className="mt-4 text-center text-[10px] text-amber-500 uppercase font-bold hover:underline">Экспортировать MP4 Видео</a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreativeEngine;
