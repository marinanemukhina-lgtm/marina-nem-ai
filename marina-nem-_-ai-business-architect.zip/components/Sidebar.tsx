
import React from 'react';
import { AppSection } from '../types';

interface SidebarProps {
  activeSection: AppSection;
  onSectionChange: (section: AppSection) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, onSectionChange }) => {
  const navItems = [
    { id: AppSection.Audit, label: 'Бизнес-Аудит', icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z' },
    { id: AppSection.Voice, label: 'AI Voice Strategist', icon: 'M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z' },
    { id: AppSection.Creative, label: 'Creative Engine', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full z-20">
      <div className="p-8">
        <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-amber-500 shadow-lg shadow-amber-500/20 mb-4">
          <img src="https://picsum.photos/seed/marina/200/200" alt="Marina Nem" className="w-full h-full object-cover" />
        </div>
        <div className="space-y-1">
           <p className="text-amber-500 font-bold text-sm tracking-wide">МАРИНА НЕМ</p>
           <p className="text-slate-400 text-xs font-medium">Digital Architect</p>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onSectionChange(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 text-sm font-medium ${
              activeSection === item.id
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-6 mt-auto">
        <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
           <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-2">My Philosophy</p>
           <p className="text-xs text-slate-300 italic leading-relaxed">
             "Мы не заменяем людей, мы даем им суперсилу."
           </p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
