
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { MARINA_SYSTEM_INSTRUCTION, MODELS } from '../constants';

const VoiceStrategist: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState<string[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const stopSession = () => {
    if (sessionRef.current) {
      // In a real implementation we'd call close, but assuming basic cleanup here
      sessionRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setIsActive(false);
    setIsConnecting(false);
  };

  const startSession = async () => {
    try {
      setIsConnecting(true);
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputAudioContext;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: MODELS.VOICE,
        callbacks: {
          onopen: () => {
            console.log('Voice session opened');
            setIsActive(true);
            setIsConnecting(false);

            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };

              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
             // Handle transcription
             if (message.serverContent?.outputTranscription) {
               const text = message.serverContent.outputTranscription.text;
               setTranscription(prev => [...prev.slice(-4), `Marina: ${text}`]);
             } else if (message.serverContent?.inputTranscription) {
               const text = message.serverContent.inputTranscription.text;
               setTranscription(prev => [...prev.slice(-4), `Вы: ${text}`]);
             }

            // Handle audio output
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outputAudioContext, 24000, 1);
              const source = outputAudioContext.createBufferSource();
              source.buffer = buffer;
              source.connect(outputAudioContext.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error('Voice Error:', e);
            stopSession();
          },
          onclose: () => {
            console.log('Voice session closed');
            stopSession();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: MARINA_SYSTEM_INSTRUCTION,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col items-center justify-center space-y-12 py-12">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-luxury text-slate-100">AI Voice Strategist</h2>
        <p className="text-slate-400 max-w-lg mx-auto leading-relaxed">
          Голосовая сессия с цифровым двойником. Мы не просто говорим, мы проектируем ваш ROI в реальном времени.
        </p>
      </div>

      <div className="relative">
        {/* Pulsing visualizer */}
        <div className={`w-64 h-64 rounded-full border-4 flex items-center justify-center transition-all duration-1000 ${
          isActive ? 'border-amber-500 shadow-[0_0_50px_rgba(245,158,11,0.4)] scale-110' : 'border-slate-800'
        }`}>
          <div className={`w-48 h-48 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center overflow-hidden relative`}>
             <img src="https://picsum.photos/seed/marina-voice/400/400" className={`w-full h-full object-cover opacity-60 transition-opacity ${isActive ? 'opacity-100' : ''}`} alt="Marina" />
             {isActive && (
               <div className="absolute inset-0 flex items-center justify-center gap-1">
                 {[1,2,3,4,5].map(i => (
                   <div key={i} className={`w-1 bg-amber-500 rounded-full animate-[voice-pulse_1s_infinite]`} style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.1}s` }}></div>
                 ))}
               </div>
             )}
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center gap-6">
        <button
          onClick={isActive ? stopSession : startSession}
          disabled={isConnecting}
          className={`px-12 py-4 rounded-full font-bold uppercase tracking-widest text-sm transition-all shadow-xl ${
            isActive 
              ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-900/20' 
              : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-900/20'
          }`}
        >
          {isConnecting ? 'Инициализация...' : isActive ? 'Завершить разбор' : 'Начать аудио-аудит'}
        </button>

        <div className="w-full max-w-xl bg-slate-900/50 rounded-2xl border border-slate-800 p-6 min-h-[12rem] flex flex-col gap-2">
           <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-2">Live Transcription</p>
           {transcription.length === 0 && <p className="text-slate-600 italic text-sm">Ожидание начала сессии...</p>}
           {transcription.map((line, i) => (
             <p key={i} className={`text-sm ${line.startsWith('Marina') ? 'text-amber-500 font-semibold' : 'text-slate-300'}`}>{line}</p>
           ))}
        </div>
      </div>

      <style>{`
        @keyframes voice-pulse {
          0%, 100% { height: 10%; }
          50% { height: 80%; }
        }
      `}</style>
    </div>
  );
};

export default VoiceStrategist;
